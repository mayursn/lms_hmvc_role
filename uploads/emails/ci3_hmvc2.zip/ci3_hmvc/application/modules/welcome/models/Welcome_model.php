<?php

class Welcome_model extends MY_Model {

	function __construct() {
		parent::__construct();
	}

	function welcome() {
		echo 'this is method of welcome model';
	}
}