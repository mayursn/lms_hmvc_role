<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Demo extends MY_Controller {

	function __construct() {
		parent::__construct();
	}

	function index() {
		$this->load->model('welcome/welcome_model');
		echo $this->welcome_model->welcome();
		echo modules::run('welcome');
	}
}